This corpus is a Malay Opinion Corpus (MOC)

============================================

The corpus contains 2000 movie reviews collected from different web pages and blogs in Malay; 1000 of them are considered positive reviews, and the other 1000 are considered negative.

=============
Please cite either one or these two papers if you use this corpus:
1- Enhanced Malay Sentiment Analysis with an Ensemble Classification Machine Learning Approach
2- Feature Selection Methods Effects on Machine Learning Approaches in Malay Sentiment Analysis